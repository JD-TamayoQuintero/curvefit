/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: MEDT2_data.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 06-Dec-2020 17:47:07
 */

/* Include Files */
#include "MEDT2_data.h"
#include "MEDT2.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_MEDT2 = false;

/*
 * File trailer for MEDT2_data.c
 *
 * [EOF]
 */
