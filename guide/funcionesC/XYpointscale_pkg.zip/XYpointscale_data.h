/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: XYpointscale_data.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 06-Dec-2020 18:04:47
 */

#ifndef XYPOINTSCALE_DATA_H
#define XYPOINTSCALE_DATA_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "XYpointscale_types.h"

/* Variable Declarations */
extern boolean_T isInitialized_XYpointscale;

#endif

/*
 * File trailer for XYpointscale_data.h
 *
 * [EOF]
 */
