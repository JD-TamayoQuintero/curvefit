/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: XYpointscale_data.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 06-Dec-2020 18:04:47
 */

/* Include Files */
#include "XYpointscale_data.h"
#include "XYpointscale.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_XYpointscale = false;

/*
 * File trailer for XYpointscale_data.c
 *
 * [EOF]
 */
