/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: MEDT_terminate.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 06-Dec-2020 17:48:20
 */

/* Include Files */
#include "MEDT_terminate.h"
#include "MEDT.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void MEDT_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for MEDT_terminate.c
 *
 * [EOF]
 */
