/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: MEDT.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 06-Dec-2020 17:48:20
 */

/* Include Files */
#include "MEDT.h"
#include "MEDT_emxutil.h"

/* Function Definitions */

/*
 * Arguments    : const emxArray_boolean_T *image
 *                emxArray_real_T *newimage
 * Return Type  : void
 */
void MEDT(const emxArray_boolean_T *image, emxArray_real_T *newimage)
{
  int i;
  emxArray_boolean_T *varargin_1;
  int b_i;
  int i1;
  int j;
  int loop_ub;
  int k;
  boolean_T maxval;
  boolean_T b;
  i = newimage->size[0] * newimage->size[1];
  newimage->size[0] = image->size[0];
  newimage->size[1] = image->size[1];
  emxEnsureCapacity_real_T(newimage, i);

  /*  numero de datos */
  i = image->size[0];
  emxInit_boolean_T(&varargin_1, 2);
  for (b_i = 0; b_i < i; b_i++) {
    i1 = image->size[1];
    for (j = 0; j < i1; j++) {
      loop_ub = image->size[1];
      k = varargin_1->size[0] * varargin_1->size[1];
      varargin_1->size[0] = 1;
      varargin_1->size[1] = image->size[1];
      emxEnsureCapacity_boolean_T(varargin_1, k);
      for (k = 0; k < loop_ub; k++) {
        varargin_1->data[k] = image->data[b_i + image->size[0] * k];
      }

      loop_ub = image->size[1];
      maxval = image->data[b_i];
      for (k = 2; k <= loop_ub; k++) {
        b = varargin_1->data[k - 1];
        maxval = (((int)maxval < (int)b) || maxval);
      }

      if (image->data[b_i + image->size[0] * j] == maxval) {
        newimage->data[b_i + newimage->size[0] * j] = 255.0;
      } else {
        newimage->data[b_i + newimage->size[0] * j] = 0.0;
      }
    }
  }

  emxFree_boolean_T(&varargin_1);
}

/*
 * File trailer for MEDT.c
 *
 * [EOF]
 */
