/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: unique.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 06-Dec-2020 18:35:09
 */

#ifndef UNIQUE_H
#define UNIQUE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "XYpointcurveselection_types.h"

/* Function Declarations */
extern void unique_vector(const emxArray_real_T *a, emxArray_real_T *b);

#endif

/*
 * File trailer for unique.h
 *
 * [EOF]
 */
