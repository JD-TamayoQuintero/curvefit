/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: XYpointcurveselection_data.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 06-Dec-2020 18:35:09
 */

/* Include Files */
#include "XYpointcurveselection_data.h"
#include "XYpointcurveselection.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_XYpointcurveselection = false;

/*
 * File trailer for XYpointcurveselection_data.c
 *
 * [EOF]
 */
