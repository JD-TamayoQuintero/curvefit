/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: XYpointcurveselection_data.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 06-Dec-2020 18:35:09
 */

#ifndef XYPOINTCURVESELECTION_DATA_H
#define XYPOINTCURVESELECTION_DATA_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "XYpointcurveselection_types.h"

/* Variable Declarations */
extern boolean_T isInitialized_XYpointcurveselection;

#endif

/*
 * File trailer for XYpointcurveselection_data.h
 *
 * [EOF]
 */
