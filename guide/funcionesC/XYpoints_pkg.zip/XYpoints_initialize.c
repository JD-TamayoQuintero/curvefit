/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: XYpoints_initialize.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 06-Dec-2020 18:12:50
 */

/* Include Files */
#include "XYpoints_initialize.h"
#include "XYpoints.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void XYpoints_initialize(void)
{
}

/*
 * File trailer for XYpoints_initialize.c
 *
 * [EOF]
 */
